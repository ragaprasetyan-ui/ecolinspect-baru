// This service is disabled to prioritize local storage and professional UI focus.
export const syncToGoogleSheet = async () => false;
